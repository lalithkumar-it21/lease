package com.example.demo.controller;

import java.math.BigInteger;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader; // Keep import, but won't use directly in this method now
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.OrderRequest;
import com.example.demo.model.OrderResponse;
import com.example.demo.model.Payment;
import com.example.demo.model.PaymentVerificationRequest; // NEW: Import the DTO
import com.example.demo.service.PaymentService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils; // For signature verification

import jakarta.servlet.http.HttpServletRequest; // Keep import, but won't use directly in this method now

@RestController
@RequestMapping("/pg")
public class RazorpayController {

	// Inject Razorpay keys from application.properties
	@Value("${razorpay1.secretid}")
	private String secretId1;

	@Value("${razorpay1.secretkey}")
	private String secretKey1;

	// Assuming a second account might exist in properties,
	// if not, simplify the logic to use only one set of keys.
	@Value("${razorpay2.secretid:}") // Default to empty string if not found
	private String secretId2;

	@Value("${razorpay2.secretkey:}") // Default to empty string if not found
	private String secretKey2;

	@Value("${razorpay.threshold}") // Inject the threshold from properties
	private int razorpayThreshold;

	@Autowired
	private PaymentService paymentService; // Inject the new PaymentService

	/**
	 * Creates a new Razorpay order.
	 *
	 * @param orderRequest Details of the order (amount, customer info).
	 * @return OrderResponse containing Razorpay order ID and other details (no secret keys).
	 */
	@RequestMapping(path = "/createOrder", method = RequestMethod.POST)
	public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest orderRequest) {
		OrderResponse response = new OrderResponse();
		RazorpayClient client;

		try {
			// Determine which Razorpay account to use based on amount and threshold
			if (orderRequest.getAmount().intValue() >= razorpayThreshold) { // Use injected threshold
				client = new RazorpayClient(secretId1, secretKey1);
				response.setPgName("razor1"); // Only for internal tracking
			} else {
				// Fallback to second set of keys if available, otherwise use first
				if (secretId2 != null && !secretId2.isEmpty()) {
					client = new RazorpayClient(secretId2, secretKey2);
					response.setPgName("razor2"); // Only for internal tracking
				} else {
					client = new RazorpayClient(secretId1, secretKey1);
					response.setPgName("razor1_fallback"); // Indicate fallback
				}
			}

			// Create the order with Razorpay
			Order order = createRazorPayOrder(client, orderRequest.getAmount());
			String orderId = (String) order.get("id");
			System.out.println("Razorpay Order ID created: " + orderId);

			// Save initial payment record in your database
			paymentService.createPaymentRecord(orderId, orderRequest.getAmount().intValue(), "created");

			response.setRazorpayOrderId(orderId);
			// It is important that applicationFee here holds the amount *in paisa*
			// as Razorpay expects it in paisa in the checkout options.
			// Your frontend sends `this.rentAmount` (e.g., 50000), which is in rupees.
			// The createRazorPayOrder method multiplies it by 100 to convert to paisa.
			// The response should reflect the amount in paisa to be correctly passed to Razorpay checkout.
			// So, if orderRequest.getAmount() is in rupees, then multiply by 100 here.
			// Or, if orderRequest.getAmount() is already expected in paisa by your backend
			// logic before this point, then `order.get("amount")` would be correct.
			// Assuming `order.get("amount")` returns the amount in paisa from Razorpay's created order.
			response.setApplicationFee("" + order.get("amount")); // Use the amount directly from Razorpay's order response

			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (RazorpayException e) {
			System.err.println("RazorpayException while creating order: " + e.getMessage());
			e.printStackTrace(); // Log full stack trace for debugging
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // Send generic 500 error to client
		} catch (Exception e) {
			System.err.println("Unexpected error while creating order: " + e.getMessage());
			e.printStackTrace(); // Log full stack trace for debugging
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // Send generic 500 error to client
		}
	}

	/**
	 * Handles payment verification initiated from the frontend after a successful Razorpay checkout.
	 * This endpoint verifies the payment signature using the order_id, payment_id, and signature
	 * received from the frontend (which got them from Razorpay).
	 *
	 * @param verificationRequest DTO containing razorpay_order_id, razorpay_payment_id, razorpay_signature.
	 * @return ResponseEntity indicating success or failure of verification and update.
	 */
	@RequestMapping(path = "/verifyPayment", method = RequestMethod.POST)
	public ResponseEntity<String> verifyPayment(@RequestBody PaymentVerificationRequest verificationRequest) { // MODIFIED: Changed signature
		System.out.println("Received frontend verification request: " + verificationRequest);

		String razorpayOrderId = verificationRequest.getRazorpay_order_id();
		String razorpayPaymentId = verificationRequest.getRazorpay_payment_id();
		String razorpaySignature = verificationRequest.getRazorpay_signature(); // Get signature from the DTO

		// Construct the string that was signed by Razorpay for verification.
		// Razorpay signs `order_id + "|" + payment_id`.
		String verificationString = razorpayOrderId + "|" + razorpayPaymentId;
		System.out.println("Verification String to check: " + verificationString);
		System.out.println("Signature received: " + razorpaySignature);

		try {
			// Utils.verifySignature expects the string that was signed, the signature, and the secret key
			boolean isVerified = Utils.verifySignature(verificationString, razorpaySignature, secretKey1);

			if (isVerified) {
				System.out.println("Razorpay signature verification successful for order: " + razorpayOrderId);
				// Update payment status in your database
				// Status for successful payment should be "success"
				Payment updatedPayment = paymentService.updatePaymentStatus(razorpayOrderId, razorpayPaymentId, "success");

				if (updatedPayment != null) {
					System.out.println("Payment status updated in DB for order: " + razorpayOrderId);
					return new ResponseEntity<>("Payment verified and status updated.", HttpStatus.OK);
				} else {
					System.err.println("Error: Payment record not found for order: " + razorpayOrderId + ". Payment ID: " + razorpayPaymentId);
					return new ResponseEntity<>("Payment record not found.", HttpStatus.NOT_FOUND);
				}
			} else {
				System.err.println("Razorpay signature verification FAILED for order: " + razorpayOrderId);
				// Log this attempt and potentially flag the order for manual review
				return new ResponseEntity<>("Signature verification failed.", HttpStatus.BAD_REQUEST);
			}
		} catch (RazorpayException e) {
			System.err.println("RazorpayException during verification: " + e.getMessage());
			e.printStackTrace();
			return new ResponseEntity<>("Internal server error during verification (Razorpay SDK issue).", HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			System.err.println("Unexpected error during payment verification: " + e.getMessage());
			e.printStackTrace();
			return new ResponseEntity<>("Internal server error during payment verification (General issue).", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Helper method to create a Razorpay Order object.
	 * @param client The RazorpayClient instance.
	 * @param amount The amount in currency units (e.g., INR).
	 * @return The created Razorpay Order.
	 * @throws RazorpayException If there's an error with the Razorpay API.
	 */
	private Order createRazorPayOrder(RazorpayClient client, BigInteger amount) throws RazorpayException {
		JSONObject options = new JSONObject();
		options.put("amount", amount.multiply(new BigInteger("100"))); // Amount in paisa
		options.put("currency", "INR");
		options.put("receipt", "txn_" + System.currentTimeMillis()); // Unique receipt ID
		options.put("payment_capture", 1); // Auto capture the payment
		return client.orders.create(options);
	}
}