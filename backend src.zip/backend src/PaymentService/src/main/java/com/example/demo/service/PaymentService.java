package com.example.demo.service;

import com.example.demo.model.Payment;
import com.example.demo.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    /**
     * Saves a new payment record to the database with an initial status.
     * @param razorpayOrderId The Razorpay Order ID.
     * @param amount The amount of the payment.
     * @param status The initial status (e.g., "created").
     * @return The saved Payment entity.
     */
    public Payment createPaymentRecord(String razorpayOrderId, int amount, String status) {
        Payment payment = new Payment();
        payment.setRazorpayOrderId(razorpayOrderId);
        payment.setAmount(amount);
        payment.setStatus(status);
        payment.setCreatedAt(LocalDateTime.now()); // Ensure creation timestamp is set
        return paymentRepository.save(payment);
    }

    /**
     * Updates an existing payment record's status and payment ID.
     * @param razorpayOrderId The Razorpay Order ID to find the record.
     * @param paymentId The Razorpay Payment ID (from webhook).
     * @param status The new status (e.g., "success", "failed").
     * @return The updated Payment entity, or null if not found.
     */
    public Payment updatePaymentStatus(String razorpayOrderId, String paymentId, String status) {
        Optional<Payment> optionalPayment = paymentRepository.findByRazorpayOrderId(razorpayOrderId);
        if (optionalPayment.isPresent()) {
            Payment payment = optionalPayment.get();
            payment.setPaymentId(paymentId);
            payment.setStatus(status);
            // Optionally update a 'completedAt' or 'updatedAt' timestamp
            return paymentRepository.save(payment);
        }
        return null; // Payment record not found
    }

    /**
     * Retrieves a payment by its Razorpay Order ID.
     * @param razorpayOrderId The Razorpay Order ID.
     * @return The Payment entity if found, otherwise empty.
     */
    public Optional<Payment> getPaymentByRazorpayOrderId(String razorpayOrderId) {
        return paymentRepository.findByRazorpayOrderId(razorpayOrderId);
    }
}
