package com.cts.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cts.model.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Integer> {
	 Optional<Tenant> findByName(String name);
}
