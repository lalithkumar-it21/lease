package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.OwnerPropertyRequestDTO;
import com.cts.dto.OwnerPropertyResponseDTO;

import com.cts.exception.OwnerNotFoundException;

import com.cts.feignclient.PropertyClient;
import com.cts.dto.Property;
import com.cts.model.Owner;

import com.cts.repository.OwnerRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public  class OwnerServiceImpl implements OwnerService {
	@Autowired
	OwnerRepository repository;
	@Autowired
	PropertyClient propertyClient;
	Logger log = LoggerFactory.getLogger(OwnerServiceImpl.class);

	// To save Owner
	@Override
	public String saveOwner(Owner owner) {
		log.info("In ownerServiceImpl saveowner method...");
		
		// Check if a request with the same owner ID already exists
//		Optional<Owner> existingOwner = repository.findById(owner.getOwnerd());
//
//		if (existingOwner.isPresent()) {
//			return "Owner with this ID already exists"; // Prevent duplicate insertion
//		}

		repository.save(owner);
		return "Owner saved successfully";
	}

	// To update Owner
	@Override
	//@Override
	public Owner updateOwner(int ownerId, Owner owner) {
	    log.info("Updating owner with ID: {}", ownerId);

	    Owner existingOwner = repository.findById(ownerId)
	        .orElseThrow(() -> new EntityNotFoundException("Owner not found for ID: " + ownerId));

	    // Update fields
	    existingOwner.setName(owner.getName());
	    existingOwner.setEmail(owner.getEmail());
	    existingOwner.setContact(owner.getContact());
	    existingOwner.setAddress(owner.getAddress());

	    return repository.save(existingOwner);
	}



//	public Owner updateOwner(Owner owner) {
//		log.info("In ownerServiceImpl updateowner method...");
//		return repository.save(owner);
//	}
//    public Owner updateOwner(Owner owner) {
//       // log.info("In OwnerServiceImpl updateOwner method, updating owner with ID: {}", owner.getOwnerId());
//        // If owner.getId() is provided, JPA's save method will perform an update.
//        // If it's null or 0 (and your ID is auto-generated), it might perform an insert.
//        // That's why setting owner.setId(id) in the controller is important for updates.
//        return repository.save(owner);
//    }

	// To get all Owner
	@Override
	public List<Owner> getAllOwner() {
		log.info("In ownerServiceImpl getallproperty method...");
		return repository.findAll();
	}

	// To delete Owner and property records
	@Transactional
	@Override
	public String deleteOwnerAndProperties(int ownerId) {
		log.info("In ownerServiceImpl deleteOwnerAndProperties method...");
		List<Property> properties = propertyClient.getPropertiesByOwner(ownerId);
		for (Property property : properties) {
			propertyClient.deleteProperty(property.getPropertyId());
		}
		repository.deleteById(ownerId);
		return "Owner and all associated properties deleted!";
	}

	// To get Owner
	@Override
	public Owner getOwner(int ownerId) throws OwnerNotFoundException {
		log.info("In ownerServiceImpl getOwner method...");
		Optional<Owner> optional = repository.findById(ownerId);
		if (optional.isPresent())
			return optional.get();
		else
			throw new OwnerNotFoundException("Invalid Owner Id");
	}
	
	// New method to find owner by email
		@Override
		public Optional<Owner> getOwnerByName(String name) {
			log.info("In ownerServiceImpl getOwnerByName method for email: {}", name);
			return repository.findByName(name);
		}

		
}
