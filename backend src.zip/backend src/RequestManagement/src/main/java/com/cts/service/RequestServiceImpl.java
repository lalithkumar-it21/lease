package com.cts.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.RequestNotFound;

import com.cts.model.Request;

import com.cts.repository.RequestRepository;

import jakarta.transaction.Transactional;

@Service
public class RequestServiceImpl implements RequestService {
	@Autowired
	RequestRepository repository;
	Logger log = LoggerFactory.getLogger(RequestServiceImpl.class);

	// To save request
	@Override
	public String saveRequest(Request request) {
		log.info("In RequestServiceImpl saverequest method...");
		// Check if a request with the same request ID already exists
		Optional<Request> existingRequest = repository.findById(request.getRequestId());

		if (existingRequest.isPresent()) {
			return "Request with this ID already exists"; // Prevent duplicate insertion
		}

		repository.save(request);
		return "Request sent successfully";
	}

	// To get request
	@Override
	public Request getRequest(int requestId) throws RequestNotFound {
		log.info("In RequestServiceImpl getrequest method...");
		Optional<Request> optional = repository.findById(requestId);
		if (optional.isPresent())
			return optional.get();
		else
			throw new RequestNotFound("Invalid Request Id");
	}
	
	
//	@Override
//	public Request getRequestsByTenantId(int tenantId) throws RequestNotFound {
//		log.info("In RequestServiceImpl getrequest method...");
//		Optional<Request> optional = repository.findById(tenantId);
//		if (optional.isPresent())
//			return optional.get();
//		else
//			throw new RequestNotFound("Invalid Request Id");
//	}

	
	@Override
	public List<Request> getRequestsByOwnerId(int ownerId) {
		log.info("In PropertyServiceImpl getPropertiesByOwnerId method...");
		List<Request> allRequests = repository.findAll();
		return allRequests.stream().filter(request -> request.getOwnerId() == ownerId).collect(Collectors.toList());
	}

	@Override
	public List<Request> getRequestsByTenantId(int tenantId) {
		log.info("In PropertyServiceImpl getPropertiesByOwnerId method...");
		List<Request> allRequests = repository.findAll();
		return allRequests.stream().filter(request -> request.getTenantId() == tenantId).collect(Collectors.toList());
	}
	@Override
	public List<Request> getRequestsByPropertyId(int propertyId) {
		log.info("In PropertyServiceImpl getPropertiesByOwnerId method...");
		List<Request> allRequests = repository.findAll();
		return allRequests.stream().filter(request -> request.getPropertyId() == propertyId).collect(Collectors.toList());
	}
	
	// To update request
	@Override
	public Request updateRequest(Request request) {
		log.info("In RequestServiceImpl updaterequest method...");
		return repository.save(request);
	}

	// To get all request
	@Override
	public List<Request> getAllRequest() {
		log.info("In RequestServiceImpl getallrequest method...");
		return repository.findAll();
	}

	// To delete request
	@Transactional
	@Override
	public String deleteRequest(int requestId) {
		log.info("In RequestServiceImpl deleterequest method...");
		Optional<Request> request = repository.findById(requestId);
		repository.delete(request.get());
		return "Request Deleted";
	}
}
