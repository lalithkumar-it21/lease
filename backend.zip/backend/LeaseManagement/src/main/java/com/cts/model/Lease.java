package com.cts.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "lease_info")
public class Lease {

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Min(value = 1, message = "Lease ID must be greater than 0")
	private int leaseId;

	@NotNull(message = "property ID cannot be null")
	//@Min(value = 1, message = "Property ID must be greater than 0")
	private int propertyId;

	@NotNull(message = "tenant ID cannot be null")
	//@Min(value = 1, message = "Tenant ID must be greater than 0")
	private int tenantId;
	
	@NotNull(message = "owner ID cannot be null")
	//@Min(value = 1, message = "Owner ID must be greater than 0")
	private int ownerId;

	

	@NotNull(message = "period is required")
	private int period;
	
	
	@NotNull(message = "Start date is required")
	@Pattern(regexp = "\\d{2}/\\d{2}/\\d{4}", message = "Start date must be in format DD-MM-YYYY")
	private String startDate;
	
	@NotNull(message = "Start date is required")
	@Pattern(regexp = "\\d{2}/\\d{2}/\\d{4}", message = "Start date must be in format DD-MM-YYYY")
	private String endDate;

	@NotNull(message = "Agreement details cannot be empty")
	@Size(min = 5, message = "Agreement details must be at least 10 characters long")
	private String agreementDetails;

	@Min(value = 1, message = "Rent amount must be greater than 0")
	private int rentAmount;

	@NotNull(message = "Status cannot be empty")
	@Pattern(regexp = "ACTIVE|EXTENDED|TERMINATED", message = "Status must be either ACTIVE, EXPIRED")
	private String leaseStatus;

}
