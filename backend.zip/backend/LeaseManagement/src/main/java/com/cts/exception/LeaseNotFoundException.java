package com.cts.exception;

public class LeaseNotFoundException extends RuntimeException{
	public LeaseNotFoundException(String message) {
		super(message);
	}


}
