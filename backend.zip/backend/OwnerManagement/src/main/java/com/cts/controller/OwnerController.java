package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.OwnerPropertyRequestDTO;

import com.cts.exception.OwnerNotFoundException;

import com.cts.model.Owner;
import com.cts.repository.OwnerRepository;
import com.cts.service.OwnerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/owner")
public class OwnerController {
	@Autowired
	OwnerService service;

//    @Autowired
//    private OwnerRepository ownerRepository;
	// To save Owner
	@PostMapping("/save")
	public ResponseEntity<String> saveOwner(@Valid @RequestBody Owner owner) {
		return ResponseEntity.ok(service.saveOwner(owner));
	}

	// To update Owner
//	@PutMapping("/update")
//	public ResponseEntity<Owner> updateOwner(@Valid @RequestBody Owner owner) {
//		return ResponseEntity.ok(service.updateOwner(owner));
//	}
	
//	  @PutMapping("/update/{id}")
//	    public ResponseEntity<Owner> updateOwner(@PathVariable int id, @Valid @RequestBody Owner owner) {
//	        // Ensure the ID from the path is set in the owner object
//	        // This is crucial if your service relies on the ID being present in the entity
//	        owner.setId(id);
//	        return ResponseEntity.ok(service.updateOwner(owner));
//	    }
	
//	@PutMapping("/update")
//	public ResponseEntity<Owner> updateOwner(@Valid @RequestBody Owner owner) {
//		return ResponseEntity.ok(service.updateOwner(owner));
//	}
	@PutMapping("/update/{ownerId}")
	public ResponseEntity<Owner> updateOwner(@PathVariable int ownerId, @Valid @RequestBody Owner owner) {
	    return ResponseEntity.ok(service.updateOwner(ownerId, owner));
	}
	
	
	  
//	  @PutMapping("/update") // Ensure ID is present in URL
//	  public ResponseEntity<Owner> updateOwner(@PathVariable int ownerId, @Valid @RequestBody Owner owner) {
////	      if (ownerId != owner.getOwnerid()) {
////	          return ResponseEntity.badRequest().body(null); // Ensure IDs match
////	      }
//	      return ResponseEntity.ok(service.updateOwner(owner));
//	  }


	// To get Owner
	@GetMapping("/fetchById/{ownerId}")

	public Owner getOwner(@PathVariable("ownerId") int ownerId) throws OwnerNotFoundException {
		return service.getOwner(ownerId);

	}

	// To delete Owner
	@DeleteMapping("/deleteOwnerAndProperties/{ownerId}")
	public String deleteOwnerAndProperties(@PathVariable("ownerId") int ownerId) {
		return service.deleteOwnerAndProperties(ownerId);
	}

	// To get all Owner
	@GetMapping("/fetchAll")
	public List<Owner> getAllOwner() {
		return service.getAllOwner();
	}
	
	// New endpoint to get owner ID by email
		@GetMapping("/id-by-name/{name}")
		public ResponseEntity<Integer> getOwnerIdByName(@PathVariable String name) {
			Optional<Owner> owner = service.getOwnerByName(name); // Use the service method
			if (owner.isPresent()) {
				return ResponseEntity.ok(owner.get().getOwnerId());
			} else {
				return ResponseEntity.status(HttpStatus.SC_NOT_FOUND).body(null);
			}
		}
	
//	 @GetMapping("/id-by-email/{email}") // Choose a descriptive path, e.g., /owner/id-by-email/{email}
//	    public ResponseEntity<Integer> getOwnerIdByEmail(@PathVariable String email) {
//	        Optional<Owner> owner = ownerRepository.findByEmail(email);
//	        if (owner.isPresent()) {
//	            return ResponseEntity.ok(owner.get().getOwnerId());
//	        } else {
//	            // Log a warning or return a more specific error if needed
//	            return ResponseEntity.status(HttpStatus.SC_NOT_FOUND).body(null);
//	        }
//	    }
}
