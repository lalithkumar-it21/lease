package com.example.demo.model;

import java.time.LocalDateTime;

// No @UpdateTimestamp is needed if you're not explicitly tracking update time,
// but it's fine if you intend to use it later.
// import org.hibernate.annotations.UpdateTimestamp; // No need for this import if not used

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType; // NEW: Import this
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor; // Changed to NoArgsConstructor as @RequiredArgsConstructor is mostly for final fields

// Changed to @NoArgsConstructor for proper bean creation
@Data
@NoArgsConstructor // Added NoArgsConstructor
@AllArgsConstructor
@Entity
public class Payment {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // IMPORTANT: Added strategy
    private Long id;
 
    private String razorpayOrderId;
    private String paymentId;
    private String status; // created, success, failed, etc.
 
    private int amount;
 
    private LocalDateTime createdAt = LocalDateTime.now(); // Initialize upon creation

    // You can remove @RequiredArgsConstructor if you add @NoArgsConstructor and @AllArgsConstructor.
    // If you explicitly want a constructor with specific non-nullable fields, then use @RequiredArgsConstructor
    // in conjunction with @NonNull for those fields. For simple entities, @Data, @NoArgsConstructor, @AllArgsConstructor is fine.
}
