package com.example.demo.repository;

import java.util.Optional; // Import Optional

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Payment;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
	// Method to find a Payment record by its Razorpay Order ID
	Optional<Payment> findByRazorpayOrderId(String orderId);
}
